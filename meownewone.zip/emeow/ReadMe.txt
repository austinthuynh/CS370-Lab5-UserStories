# CS 370 JavaFX Card Game

This project is a JavaFX card game application created for CS 370.

The program includes two main parts:

- Part 1: Display a full 52-card deck
- Part 4: High Card game between the player and computer

The application uses JavaFX for the graphical interface and Maven to manage dependencies and run the project.

---

# Features

## Part 1 - Card Display

The Part 1 tab displays all 52 cards in a standard playing card deck.

Features include:

- All 52 cards displayed
- Hearts
- Diamonds
- Clubs
- Spades
- Ranks from 2 through Ace
- Shuffle Deck button
- Scrollable card display

Pressing the Shuffle Deck button randomizes the order of the cards.

---

## Part 4 - High Card Game

The Part 4 tab contains a simple High Card game.

Features include:

- Player vs. computer
- Player score
- Computer score
- Draw Card button
- New Game button
- Remaining card counter
- Automatic deck shuffling
- Win/loss messages
- Card values from 2 through Ace

### Game Rules

- The player and computer each draw one card.
- The higher ranked card wins the round.
- Ace is the highest card.
- Suits do not affect card value.
- If both cards have the same rank, the round is a tie.
- Ties award no points.
- The first player to reach 10 points wins.
- Pressing New Game resets the scores and creates a newly shuffled deck.

---

# Requirements

Before running the project, make sure the following software is installed:

- Java JDK 21
- Apache Maven
- Internet connection for the first launch

The internet connection is needed the first time because Maven downloads the JavaFX libraries automatically.

---

# Project Structure

The project should look similar to this:

```text
CardGameProject/
│
├── pom.xml
├── README.md
│
└── src/
    └── main/
        └── java/
            └── CardGameApp.java